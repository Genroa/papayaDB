package papayaDB.db;

import io.vertx.core.AbstractVerticle;

/**
 * Cette classe représente la Thread qui s'occupe de la création d'index de base. Celle-ci récupère
 * les informations des index à créer dans les DatabaseCollection.
 */
public class DatabaseIndexManager extends AbstractVerticle {
	
}
