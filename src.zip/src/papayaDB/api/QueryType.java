package papayaDB.api;

public enum QueryType {
	GET,
	INSERT,
	CREATEDB,
	DELETEDB,
	DELETEFIELD,
	UPDATE,
	EXPORTALL,
	DELETEDOCUMENT;
} 
